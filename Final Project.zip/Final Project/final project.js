function login() {
    var user = document.getElementById("username").value;
    var passwd = document.getElementById("password").value;
    if(user == "user1" && passwd == "passAdmin01#") {
      alert("Welcome");
      window.open('./q3.html');
      return true;
    } else {
      alert("Username or Password incorrect");
      return false;
    }
  }
  
  var list = [];
  for (var i = 0; i < 11; i++) {
    var obj = {
      A: '',
      B: '',
      C: '',
      D: ''
    };
    list.push(obj);
  }
  
  let result1, result2, result3, result4;
  
  function check1(p) {
    var myselect = document.getElementById("question1" + p);
    var index1 = myselect.selectedIndex;
    list[p - 1].A = myselect.options[index1].value;
    computed();
  }
  
  function check2(p) {
    var myselect = document.getElementById("question2" + p);
    var index1 = myselect.selectedIndex;
    list[p - 1].B = myselect.options[index1].value;
    computed();
  }
  
  function check3(p) {
    var myselect = document.getElementById("question3" + p);
    var index1 = myselect.selectedIndex;
    list[p - 1].C = myselect.options[index1].value;
    computed();
  }
  
  function check4(p) {
    var myselect = document.getElementById("question4" + p);
    var index1 = myselect.selectedIndex;
    list[p - 1].D = myselect.options[index1].value;
    computed();
  }
  
  function computed() {
    let total1 = 0;
    let total2 = 0;
    let total3 = 0;
    let total4 = 0;
  
    for (var i = 0; i < 11; i++) {
      var html = "<tr>";
      html += "<td>" + (i + 1) + "</td>" +
              "<td>" + list[i].A + "</td>" +
              "<td>" + list[i].B + "</td>" +
              "<td>" + list[i].C + "</td>" +
              "<td>" + list[i].D + "</td>";
      html += "</tr>";
  
      if (list[i].A > 0) {
        total1 += parseInt(list[i].A);
      }
      if (list[i].B > 0) {
        total2 += parseInt(list[i].B);
      }
      if (list[i].C > 0) {
        total3 += parseInt(list[i].C);
      }
      if (list[i].D > 0) {
        total4 += parseInt(list[i].D);
      }
      document.getElementById("table1" + (i + 1)).innerHTML = html;
    }
  
    document.getElementById('total1').value = total1 > 0 ? total1 : '';
    document.getElementById('total2').value = total2 > 0 ? total2 : '';
    document.getElementById('total3').value = total3 > 0 ? total3 : '';
    document.getElementById('total4').value = total4 > 0 ? total4 : '';
    result1 = total1 > 0 ? total1 : '';
    result2 = total2 > 0 ? total2 : '';
    result3 = total3 > 0 ? total3 : '';
    result4 = total4 > 0 ? total4 : '';
    }
    
    window.onload = function () {
    computed();
    }
    
    function myFunction() {
    let error = "";
    let number = 0;
    for (i = 0; i < 11; i++) {
    number = Math.pow(list[i].A, 3) + Math.pow(list[i].B, 3) + Math.pow(list[i].C, 3) + Math.pow(list[i].D, 3);
    if (number != 100) {
    error += "question" + (i + 1) + " error\n";
    }
    }
    
    if (error == "") {
    if (result1 > result2 && result1 > result3 && result1 > result4) {
    window.open('./Are you…Orange.html');
    } else if (result2 > result1 && result2 > result3 && result2 > result4) {
    window.open('./Are you…Green.html');
    } else if (result3 > result1 && result3 > result2 && result3 > result4) {
    window.open('./Are you…Blue.html');
    } else {
    window.open('./Are you…Gold.html');
    }
    } else {
    alert(error);
    }
    }